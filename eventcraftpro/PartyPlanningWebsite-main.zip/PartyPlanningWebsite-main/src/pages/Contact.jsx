
const Contact=()=>{
    return(
<div>contact</div>
    )
}
export default Contact