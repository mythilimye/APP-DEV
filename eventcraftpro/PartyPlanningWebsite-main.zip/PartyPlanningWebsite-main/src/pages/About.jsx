import Nvbar from "../components/nvbar"

const About=()=>{
    return(
<div>
    <header>
        about
        <Nvbar/>
    </header>
    <section>
        <div>
            
        </div>
    </section>
</div>
    )
}
export default About